#!/usr/bin/python3
import boto3
import json

client = boto3.client('ec2', region_name='us-east-1')
#response = client.describe_images(Owners=['amazon'])
response = client.describe_images(Owners=['amazon'])
#for ami in response['Images']:
#    print(ami['PlatformDetails']) 
jsn_list = json.loads(json.dumps(response['Images'])) 
for lis in jsn_list:
       for key,val in lis.items():
           #print(lis['Description'])
           if val == 'amazon/Deep Learning AMI (Ubuntu 18.04) Version 52.0':
              print(lis['ImageId']) 
           #   print(lis['ImageLocation'].strip('amazon/'),lis['ImageId']) 
           #print(val) 
           #if val in ['amazon/RHEL_7.9-x86_64-SQL_2017_Standard-2021.10.20','Cloud9Ubuntu-2020-08-26T15-11','amazon/suse-manager-3-2-server-byos-v20200106-hvm-ssd-x86_64']:
           #   print(lis['ImageLocation'].strip('amazon/'),lis['ImageId']) 
           #print(val) 
